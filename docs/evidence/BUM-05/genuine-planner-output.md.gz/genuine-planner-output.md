# BUM-05 Readiness Probe Specification — FS-011 Planner Contract (Planning-Only)

> **READ-ONLY READINESS PROBE ONLY.** This document is a bounded planning
> specification. It authorizes **no implementation, no execution, no tool
> invocation, no dependency install, no provider/model substitution, and no
> application code**. "Model output is not implementation evidence."
> This artifact does **not** start FS-011 and does **not** claim any auth code,
> test, or review result.

## 0. Status, authority, stewardship

- **Mode:** read-only planning. No file in the repo is written by this probe.
  Every path named below is **proposed future ownership only**.
- **Stewardship:** Planner retains ownership of `pipeline/spec.md`,
  `docs/FS-011.md`, and handoff records. This probe does not edit them beyond
  producing this spec.
- **Closure decision:** The prior BUM-05 readiness invocation returned a
  non-empty, inspected planner artifact. That artifact is **reference input**,
  not execution evidence. This probe's job is to bound the follow-ups below so
  the next authorized Planner pass can resolve them **before** any builder edits.
- **Source preservation (binding):** FinderShip repository sources are
  preserved as-is. No source path is modified, renamed, or deleted by this
  probe.

## 1. Five roles (unchanged, configuration-only)

The five stages/roles are preserved explicitly and are **identities of
configuration, not execution evidence**:

1. **Planner** — owns `pipeline/spec.md`, `docs/FS-011.md`, handoffs. No code.
2. **Frontend** — owns `apps/web/src/app/(auth)/**`,
   `apps/web/src/components/auth/**`,
   `apps/web/src/app/(protected)/app/protected-content.tsx`.
3. **Backend** — owns `apps/web/src/server/auth/**`,
   `apps/web/src/app/auth/**`, `apps/web/src/app/(protected)/app/page.tsx`,
   `apps/web/src/proxy.ts`.
4. **Tester** — owns the exact `apps/web/test/*` filenames listed in the
   reference spec. Mocks/fixtures only in the harness file.
5. **Reviewer** — independent verification; no self-approval.

Coordinator (Hermes) remains the **sole** writer of
`apps/web/package.json`, `pnpm-lock.yaml`, `.env.example`, root test-script
integration, and any bounded runner config — **only after** a future contract
is accepted. This probe does not trigger that integration.

## 2. Coordinator follow-ups this probe must bound (resolution requirements)

The next authorized Planner specification must resolve, in writing, each item
below. This probe records them as **open planning requirements**, not as
resolved facts and not as implementation tasks.

### 2.1 Test runner

- The repository's installed runner is **Vitest 5.0.5** with the repository's
  existing config. The spec must use that runner/config; it must **not**
  substitute Jest, node:test, or any other runner, and must not invent a new
  config unless Coordinator confirms one is strictly required.
- Required claim to verify: an explicit, exact invocation exists that runs the
  `apps/web/test` case files.

### 2.2 Component return types

- Component return types must use **explicit
  `React.JSX.Element` / `ReactElement`** annotations with an explicit React
  import. Do **not** rely on a presumed global `JSX` namespace.

### 2.3 Callback GET ordering

- The callback **GET** must **not** consume a single-use token before an
  explicit **POST** confirmation. Token-type verification and consumption
  ordering must be defined so mail-scanner/prefetch GETs cannot burn the token.
  This is a planning invariant; no code is written here.

### 2.4 Supabase email-template token types

- Any email-template handling must be limited to the **allowlisted token types
  `email` and `recovery`**, verified against the **real installed SDK** before
  any builder codes against it. No other token types may be assumed.
- Exact compatible pins for `@supabase/ssr` and `@supabase/supabase-js`
  against Next 16 / React 19 must be re-verified from the live registry and
  peer graph by Coordinator before any import is finalized.

## 3. FILE BOUNDARIES (proposed future ownership — nothing authorized now)

> **No file below is created, modified, or written by this probe.** These are
> the same ownership boundaries as the reference FS-011 planner artifact and
> are restated here only to bound the future contract.

### 3.1 Frontend (future — proposed only)

- `apps/web/src/app/(auth)/login/page.tsx`
- `apps/web/src/app/(auth)/register/page.tsx`
- `apps/web/src/app/(auth)/forgot-password/page.tsx`
- `apps/web/src/app/(auth)/reset-password/page.tsx`
- `apps/web/src/components/auth/auth-form-shell.tsx`
- `apps/web/src/components/auth/login-form.tsx`
- `apps/web/src/components/auth/register-form.tsx`
- `apps/web/src/components/auth/forgot-password-form.tsx`
- `apps/web/src/components/auth/reset-password-form.tsx`
- `apps/web/src/components/auth/field-error.tsx`
- `apps/web/src/components/auth/form-status.tsx`
- `apps/web/src/app/(protected)/app/protected-content.tsx`

### 3.2 Backend (future — proposed only)

- `apps/web/src/server/auth/client.ts`
- `apps/web/src/server/auth/session.ts`
- `apps/web/src/server/auth/outcomes.ts`
- `apps/web/src/server/auth/validation.ts`
- `apps/web/src/server/auth/redirects.ts`
- `apps/web/src/server/auth/actions.ts`
- `apps/web/src/server/auth/logout-route.ts`
- `apps/web/src/app/auth/logout/route.ts`
- `apps/web/src/app/auth/callback/route.ts`
- `apps/web/src/app/auth/confirm/route.ts`
- `apps/web/src/app/(protected)/app/page.tsx`
- `apps/web/src/proxy.ts`

### 3.3 Tester (future — proposed only, exact filenames, no globs)

- `apps/web/test/auth-register.test.ts`
- `apps/web/test/auth-login.test.ts`
- `apps/web/test/auth-protected-gate.test.ts`
- `apps/web/test/auth-session-refresh.test.ts`
- `apps/web/test/auth-logout.test.ts`
- `apps/web/test/auth-recovery.test.ts`
- `apps/web/test/auth-callback.test.ts`
- `apps/web/test/auth-password-update.test.ts`
- `apps/web/test/auth-csrf-redirect.test.ts`
- `apps/web/test/auth-unavailable.test.ts`
- `apps/web/test/auth-accessibility.test.tsx`
- `apps/web/test/helpers/auth-test-harness.ts` (fixtures/mocks only)

### 3.4 Coordinator (future — proposed only)

- `apps/web/package.json`, `pnpm-lock.yaml`, `.env.example`,
  root `package.json` test-script integration, `apps/web/README.md`
  (auth setup docs), and bounded runner config **only if strictly required**.

### 3.5 This probe

- **Writes:** this specification content only (`pipeline/spec.md`).
- **Touches no other path.** No source, test, config, lockfile, or env file is
  affected.

## 4. EXPORTED SIGNATURES (contract reference — none created by this probe)

The following remain the **planned** contract from the reference artifact and
are restated for continuity only. Nothing here is exported, compiled, or
tested by this probe.

- `outcomes.ts`: `AuthFormState`, `AuthFormStatus`, `AuthFieldErrors`,
  `initialAuthFormState`, `toUnavailable`, `toValidationError`.
- `client.ts`: `createSupabaseServerClient(): Promise<SupabaseClient>`
  (server-only, per-request, awaited Next cookies).
- `session.ts`: `getVerifiedUser(): Promise<VerifiedUser | null>`,
  `requireVerifiedUser(): Promise<VerifiedUser>`, `AuthUnverifiedError`.
- `validation.ts`: `AUTH_EMAIL_MAX`, `AUTH_PASSWORD_MIN`, `validateEmail`,
  `validatePassword`, `validateRegisterForm`, `validateLoginForm`,
  `validateRecoveryForm`, `validatePasswordUpdateForm`.
- `redirects.ts`: `resolveSameOriginPath`, `getCanonicalOrigin`.
- `actions.ts` (`'use server'`): `registerAction`, `loginAction`,
  `requestRecoveryAction`, `updatePasswordAction` — none accepts
  `userId`/role/plan.
- Routes: logout `POST` only (no `GET` export); callback `GET`;
  confirm `POST`.
- Components: `AuthFormShell`, `FieldError`, `FormStatus`, `LoginForm`,
  `RegisterForm`, `ForgotPasswordForm`, `ResetPasswordForm`,
  `ProtectedContent({ user })`.

## 5. PERMITTED TOKENS / libraries (planning reference)

- Styling: **Tailwind v4 utility classes only**. No theme module is invented;
  no `Colors.*` token is assumed (repo has no `src/theme/colors.ts`).
- Forms: React 19 `useActionState` + native form actions. No form library.
- Libraries (future, Coordinator-pinned only): `@supabase/ssr`,
  `@supabase/supabase-js` (server-side only).
- Cookies: `next/headers` `cookies()` (awaited).

## 6. NEGATIVE CONSTRAINTS

- **No tools, shell, function calls, or command syntax** may be emitted or
  executed by this probe.
- **No provider or model substitution.** Roles stay on their configured
  identities.
- **No application code** is written, generated, or proposed as runnable.
- **No file writes** beyond this spec; all file boundaries are proposed future
  ownership only.
- **Do not start FS-011.** This probe does not authorize builders.
- No edits to `packages/shared/**`, migrations, business DB schema,
  `IDEA.md`, `docs/FS-011_HANDOFF.md`, `app/layout.tsx`, `app/page.tsx`,
  `app/globals.css`.
- No `getSession()`-based authorization, decoded-JWT trust, client-supplied
  identity, service-role client, or global mutable auth state.
- No raw provider error/token/password leakage; no account enumeration; no
  token-bearing URL reflection/referrers/response caching (auth responses
  `private, no-store`).
- No live email, signup, purchase, deployment, main merge, or FS-012/FS-013
  work.
- No self-approval; Reviewer independence is preserved.
- Preserve the `braces@3.0.3` security exception expiring
  **2026-11-17 00:00 UTC**.

## 7. EVIDENCE (not claimed by this probe)

This probe produces **no** install, build, test, security-audit, or review
evidence. Any future evidence claims belong to later authorized stages and must
record exact versions, commands, exit codes, test counts, mock-vs-browser-vs-live
limits, changed paths, head SHA, and exact-head CI in `docs/FS-011.md`. Draft PR
only; founder accepts; never merge to main.

## 8. NEEDS CONTEXT

- **Registry pins unconfirmed.** Exact compatible `@supabase/ssr` /
  `@supabase/supabase-js` versions for Next 16 / React 19 are not confirmed by
  this probe; Coordinator must resolve from the live registry and peer graph.
- **Vitest invocation unconfirmed.** Whether the repository's existing
  Vitest 5.0.5 config already runs `apps/web/test/*` is unverified; Coordinator
  owns the exact invocation if it must be added.
- **Supabase token-type mechanism unconfirmed.** That the allowlisted token
  types are exactly `email` and `recovery` — and that GET does not consume
  before POST — must be re-verified against the **real installed SDK** and
  current official docs before any builder codes it. Assertions here are
  design intent, not verified behavior.
- **Repository tree not re-read by this probe.** No `ls`/`find`/`cat` was
  available; if the real tree diverges from §3, the future Planner pass must
  reconcile before the contract is accepted.
- **Authorization state.** This probe is readiness-only. A separate explicit
  authorization is required to open FS-011 and to trigger Coordinator
  dependency integration.